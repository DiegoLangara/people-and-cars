import React, { useState, useEffect } from 'react';
import { useMutation, gql } from '@apollo/client';
import { Button, Input, Form, Col } from 'antd';
import { IoPersonAddOutline } from "react-icons/io5";
import { IoCloseCircleOutline } from "react-icons/io5";


const ADD_PERSON = gql`
  mutation AddPerson($firstName: String!, $lastName: String!) {
    addPerson(firstName: $firstName, lastName: $lastName) {
      id
      firstName
      lastName
    }
  }
`;

const UPDATE_PERSON = gql`
  mutation UpdatePerson($id: ID!, $firstName: String!, $lastName: String!) {
    updatePerson(id: $id, firstName: $firstName, lastName: $lastName) {
      id
      firstName
      lastName
    }
  }
`;

const PersonForm = ({ person, refetchPeople, onSuccess }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const [addPerson] = useMutation(ADD_PERSON, {
    onCompleted: () => {
      resetForm();
      refetchPeople();
      onSuccess();
    },
  });

  const [updatePerson] = useMutation(UPDATE_PERSON, {
    onCompleted: () => {
      resetForm();
      refetchPeople();
      onSuccess();
    },
  });

  useEffect(() => {
    if (person) {
      setFirstName(person.firstName);
      setLastName(person.lastName);
      setIsUpdating(true);
    }
  }, [person]);

  const handleSubmit = () => {
    if (isUpdating) {
      updatePerson({ variables: { id: person.id, firstName, lastName } });
    } else {
      addPerson({ variables: { firstName, lastName } });
    }
  };

  const resetForm = () => {
    setFirstName('');
    setLastName('');
    setIsUpdating(false);
  };

  return (
<Form layout="vertical" onFinish={handleSubmit} style={{  }}>
  <div className='PersonFromContainer'>
<Col span={24}><h2>Add a person</h2>
</Col>
    <Col span={24}>
      <Form.Item label="First Name" required>
        <Input
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          placeholder="Enter First Name"
          required
          style={{ color: 'white', backgroundColor: '#444' }}
        />
      </Form.Item>
    </Col>
    <Col span={24}>
      <Form.Item label="Last Name" required>
        <Input
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          placeholder="Enter Last Name"
          required
          style={{ color: 'white', backgroundColor: '#444' }}
        />
      </Form.Item>
    </Col>
  <div className='formButtons'>
  <Button type="primary" htmlType="submit">
    <IoPersonAddOutline style={{ fontSize: '16px' }} /> {isUpdating ? 'Update Person' : 'Add Person'}
  </Button>
  {isUpdating && (
    <Button style={{ marginLeft: '10px' }} onClick={resetForm}>
     <IoCloseCircleOutline style={{ fontSize: '20px' }} />  Cancel
    </Button>
  )}
</div>
</div>
</Form>
  );
};

export default PersonForm;
