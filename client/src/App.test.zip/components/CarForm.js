import React, { useState, useEffect } from 'react';
import { useMutation, useQuery, gql } from '@apollo/client';
import { Button, Form, Row, Col, InputNumber, Select as AntSelect } from 'antd';
import debounce from 'lodash.debounce';
import { IoCarSportOutline } from "react-icons/io5";
import { IoCloseCircleOutline } from "react-icons/io5";
import '../App.css';

const { Option } = AntSelect;

const GET_CAR_MAKES = gql`
  query GetCarMakes {
    carMakes {
      Make_ID
      Make_Name
    }
  }
`;

const CarForm = ({ car, people, refetchCars, onSuccess }) => {
  const currentYear = new Date().getFullYear();
  const [year, setYear] = useState(currentYear);
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [price, setPrice] = useState('');
  const [personId, setPersonId] = useState('');
  const [filteredMakes, setFilteredMakes] = useState([]);
  const [models, setModels] = useState([]);
  const [isUpdating, setIsUpdating] = useState(false);

  const { data: makesData } = useQuery(GET_CAR_MAKES);
  const makes = makesData?.carMakes || [];

  const [addCar] = useMutation(gql`
    mutation AddCar($year: Int!, $make: String!, $model: String!, $price: Float!, $personId: ID!) {
      addCar(year: $year, make: $make, model: $model, price: $price, personId: $personId) {
        id
        year
        make
        model
        price
        personId
      }
    }
  `, {
    onCompleted: () => {
      resetForm();
      refetchCars();
      onSuccess();
    },
  });

  const [updateCar] = useMutation(gql`
    mutation UpdateCar($id: ID!, $year: Int!, $make: String!, $model: String!, $price: Float!, $personId: ID!) {
      updateCar(id: $id, year: $year, make: $make, model: $model, price: $price, personId: $personId) {
        id
        year
        make
        model
        price
        personId
      }
    }
  `, {
    onCompleted: () => {
      resetForm();
      refetchCars();
      onSuccess();
    },
  });

  // Populate form fields when editing an existing car
  useEffect(() => {
    if (car) {
      setYear(car.year);
      setMake(car.make);
      setModel(car.model);
      setPrice(car.price);
      setPersonId(car.personId);
      setIsUpdating(true);
    }
  }, [car]);

  // Debounced function to filter makes after user input
  const debouncedFetchMakes = debounce((input) => {
    if (input.length >= 3) {
      const filtered = makes.filter((make) =>
        make.Make_Name.toLowerCase().includes(input.toLowerCase())
      );
      setFilteredMakes(filtered);
    } else {
      setFilteredMakes(makes); // Show all makes if input is less than 3 characters
    }
  }, 300);

  const handleMakeInputChange = (input) => {
    debouncedFetchMakes(input);
  };

  const handleMakeDropdownVisibleChange = (open) => {
    if (open && filteredMakes.length === 0) {
      setFilteredMakes(makes); // Show all makes when the dropdown is opened
    }
  };

    // Keypress handler to only allow numeric input
    const handleNumberKeyPress = (event) => {
      const charCode = event.which ? event.which : event.keyCode;
      if (charCode < 48 || charCode > 57) {
        event.preventDefault();
      }
    };
  
    // Keypress handler to allow numeric input and decimal point for price
    const handlePriceKeyPress = (event) => {
      const charCode = event.which ? event.which : event.keyCode;
      if (
        (charCode < 48 || charCode > 57) && // Not a digit
        charCode !== 46 // Not a decimal point
      ) {
        event.preventDefault();
      }
    };

  // Fetch models after make is selected
  useEffect(() => {
    if (make) {
      fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/getmodelsformake/${make}?format=json`)
        .then(response => response.json())
        .then(data => {
          const formattedModels = data.Results.length > 0
            ? data.Results.map(model => ({
                value: model.Model_Name,
                label: model.Model_Name,
              }))
            : [{ value: 'N/A', label: 'N/A' }];
          setModels(formattedModels);
        })
        .catch(error => {
          console.error('Error fetching models:', error);
          setModels([{ value: 'N/A', label: 'N/A' }]);
        });
    } else {
      setModels([]);
    }
  }, [make]);

  const handleSubmit = () => {
    if (isUpdating) {
      updateCar({
        variables: {
          id: car.id,
          year: parseInt(year),
          make,
          model,
          price: parseFloat(price),
          personId,
        },
      });
    } else {
      addCar({
        variables: {
          year: parseInt(year),
          make,
          model,
          price: parseFloat(price),
          personId,
        },
      });
    }
  };

  const resetForm = () => {
    setYear(currentYear);
    setMake('');
    setModel('');
    setPrice('');
    setPersonId('');
    setIsUpdating(false);
  };

  const isFormDisabled = people.length === 0;

  return (
    <Form layout="vertical" onFinish={handleSubmit} style={{ height:'100%', }}>
<h2>Add a car to a person</h2>
      <Row gutter={16} className=''>
        
        <Col span={12}>
          <Form.Item label="Make" required>
            <AntSelect
              showSearch
              value={make || undefined} 
              onSearch={handleMakeInputChange}
              onChange={(value) => setMake(value)}
              placeholder="Select Make (min 3 chars)"
              filterOption={false}
              onDropdownVisibleChange={handleMakeDropdownVisibleChange}
              disabled={isFormDisabled}
            >
              {filteredMakes.map((make) => (
                <Option key={make.Make_ID} value={make.Make_Name}>
                  {make.Make_Name}
                </Option>
              ))}
            </AntSelect>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="Model" required>
            <AntSelect
              showSearch
              value={model || undefined}
              onChange={(value) => setModel(value)}
              options={models}
              placeholder="Select Model"
              disabled={!make || isFormDisabled}
            />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="Year" required>
            <InputNumber
              value={year}
              onChange={(value) => setYear(value)}
              placeholder="Enter Year"
              required
              style={{ width: '100%' }}
              disabled={isFormDisabled}
              onKeyPress={handleNumberKeyPress} 
            />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="Price" required>
            <InputNumber
              value={price}
              onChange={(value) => setPrice(value)}
              placeholder="Enter Price"
              required
              formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
              parser={(value) => value.replace(/\$\s?|(,*)/g, '')}
              style={{ width: '100%' }}
              disabled={isFormDisabled}
              onKeyPress={handlePriceKeyPress}
            />
          </Form.Item>
        </Col>
      </Row>
      <Form.Item label="Person" required>
        <AntSelect
          showSearch
          value={personId}
          onChange={(value) => setPersonId(value)}
          placeholder="Select Person"
          disabled={isFormDisabled}
        >
          {people.map((person) => (
            <Option key={person.id} value={person.id}>
              {person.firstName} {person.lastName}
            </Option>
          ))}
        </AntSelect>
      </Form.Item>
      <div className='formButtons'>
      <Button type="primary" htmlType="submit" disabled={isFormDisabled}>
        <IoCarSportOutline style={{ fontSize: '20px' }} /> {isUpdating ? 'Update Car' : 'Add Car'}
      </Button>
      {isUpdating && (
          <Button style={{ marginLeft: '10px' }} onClick={resetForm}>
          <IoCloseCircleOutline style={{ fontSize: '20px' }} />  Cancel
         </Button>
      )}
      </div>
    </Form>
  );
};

export default CarForm;
