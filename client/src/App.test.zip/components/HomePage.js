// File: HomePage.js
import React, { useState, useRef } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import PersonForm from './PersonForm';
import CarForm from './CarForm';

import carBg from '../assets/car-bg2.jpg';
import { BiMessageSquareEdit, BiMessageSquareX } from "react-icons/bi";
import { Card, Button, Typography, Box, Grid } from '@mui/material';

const GET_PEOPLE = gql`
  query GetPeople {
    people {
      id
      firstName
      lastName
      cars {
        id
        year
        make
        model
        price
      }
    }
  }
`;

const DELETE_PERSON = gql`
  mutation DeletePerson($id: ID!) {
    deletePerson(id: $id) {
      id
    }
  }
`;

const DELETE_CAR = gql`
  mutation DeleteCar($id: ID!) {
    deleteCar(id: $id) {
      id
    }
  }
`;

function HomePage() {
  const { data, loading, error, refetch } = useQuery(GET_PEOPLE);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [selectedCar, setSelectedCar] = useState(null);
  const personFormRef = useRef(null);
  const carFormRef = useRef(null);
  const [deletePersonMutation] = useMutation(DELETE_PERSON, {
    onCompleted: () => {
      refetch();
      setSelectedPerson(null);
    },
  });

  const [deleteCarMutation] = useMutation(DELETE_CAR, {
    onCompleted: () => {
      refetch();
      setSelectedCar(null);
    },
  });

  const deleteSelectedPerson = (person) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this person? This will also delete all associated cars.");
    if (confirmDelete) {
      deletePersonMutation({ variables: { id: person.id } });
    }
  };

  const deleteSelectedCar = (car) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this car?");
    if (confirmDelete) {
      deleteCarMutation({ variables: { id: car.id } });
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;
  const handleEditPerson = (person) => {
    setSelectedPerson(person);
    if (personFormRef.current) {
      personFormRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  const handleEditCar = (car) => {
    setSelectedCar(car);
    if (carFormRef.current) {
      carFormRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  return (
    <Box>
    <div className='carGrid'><h1>People & Cars</h1>
    <figure><img src={carBg} alt="car" style={{ width: '100%', height: 'auto' }} /></figure>
   <div className='Forms'>
      <div className="PersonForm"  id="PersonForm" ref={personFormRef}>
        
        <PersonForm
          person={selectedPerson}
          refetchPeople={refetch}
          onSuccess={() => setSelectedPerson(null)}
          className='personForm'
         
        />
      </div>
      <div className="CarForm" id='CarForm' ref={carFormRef}>
        
        <CarForm
          car={selectedCar}
          people={data.people}
          refetchCars={refetch}
          onSuccess={() => setSelectedCar(null)}
          className='carForm'
          
        />
      </div>
      </div>
      <div className='Results' id='Results'>
      <h2>Results</h2>
      <Grid container spacing={4} sx={{ marginTop: 0, }}>
  {data.people.map((person) => (
    <Grid item xs={12} md={6} lg={4} key={person.id} className='resultsCars'>
      <Card variant="elevation" sx={{
         height: 'calc(100% - 3rem)',
        backgroundColor: '#474747', 
        color: 'white', 
        padding: 3, 
        boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        borderRadius: 3,
      }}>
        <div className='personHeader'>
        <Typography variant="h5" sx={{ marginBottom: 2 }} >
          {person.firstName} {person.lastName}
        </Typography>
        <div className='headerButtons'>
          <Button variant="contained" sx={{ marginRight: 0 }} onClick={() => handleEditPerson(person)}>
            <BiMessageSquareEdit style={{ fontSize: '20px' }} />
          </Button>
          <Button variant="contained" className='delBtn' onClick={() => deleteSelectedPerson(person)}>
            <BiMessageSquareX style={{ fontSize: '20px' }} />
          </Button>
          </div>
        </div>
        {person.cars.map((car) => (
          <Card key={car.id} variant="outlined"  sx={{
            marginTop: 2, 
            padding: 2, 
            backgroundColor: '#383838', 
            color: 'white',
           
          }}>
            <div className='carHeader'>
            <Typography variant="body1">
              {car.year} {car.make} {car.model} - ${car.price}
            </Typography>
            <div className='headerButtons'>
            <Button variant="contained" sx={{ marginTop: 0, marginRight: 0 }} onClick={() => handleEditCar(car)}>
              <BiMessageSquareEdit style={{ fontSize: '20px' }} />
            </Button>
            <Button variant="contained" className='delBtn'  sx={{ marginTop: 0 }} onClick={() => deleteSelectedCar(car)}>
              <BiMessageSquareX style={{ fontSize: '20px' }} />
            </Button>
            </div>
            </div>
          </Card>
        ))}
      </Card>
    </Grid>
  ))}
</Grid>
</div>
</div>
    </Box>
  );
}

export default HomePage;
