import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { useParams, Link } from 'react-router-dom';

const PERSON_WITH_CARS = gql`
  query PersonWithCars($id: ID!) {
    personWithcars(id: $id) {
      firstName
      lastName
      cars {
        id
        year
        make
        model
        price
      }
    }
  }
`;

function ShowPage() {
  const { id } = useParams();
  const { data, loading, error } = useQuery(PERSON_WITH_CARS, { variables: { id } });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div>
      <h1>{data.personWithcars.firstName} {data.personWithcars.lastName}</h1>
      <h2>Cars</h2>
      {data.personWithcars.cars.map(car => (
        <div key={car.id}>
          <p>{car.year} {car.make} {car.model} - ${car.price}</p>
        </div>
      ))}
      <Link to="/">Go Back Home</Link>
    </div>
  );
}

export default ShowPage;